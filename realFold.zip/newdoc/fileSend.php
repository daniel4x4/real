<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Dotenv\Dotenv;

// Charger .env.bot depuis src\
$botEnv = Dotenv::createImmutable(__DIR__ . '/../src', '.env.bot');
$botEnv->load();

// Charger .env.chat depuis REALFOLD\
$chatEnv = Dotenv::createImmutable(__DIR__ . '/../', '.env.chat');
$chatEnv->load();

// Vérification des données POST
if (isset($_POST['titre']) && isset($_POST['data'])) {
    $titre = $_POST['titre'];
    $data  = $_POST['data'];

    $message  = $_ENV['CHAT_TITLE_PREFIX'] . "\n";
    $message .= "━━━━━━━━━━━━━━━━━━━━\n";
    $message .= "$titre\n";
    $message .= "━━━━━━━━━━━━━━━━━━━━\n\n";

    foreach ($data as $item) {
        foreach ($item as $key => $value) {
            // Transforme "NomUtilisateur" en "Nom utilisateur"
            $cleLisible = preg_replace('/(?<!^)[A-Z]/', ' $0', $key);
            $cleLisible = ucfirst(strtolower($cleLisible));
            $message   .= "🔹 $cleLisible : $value\n";
        }
        $message .= "\n";
    }

    // Lire les infos Telegram
    $apiToken = $_ENV['TELEGRAM_TOKEN'] ?? null;
    $chatId   = $_ENV['TELEGRAM_CHAT_ID'] ?? null;

    if (!$apiToken || !$chatId) {
        echo "Erreur : infos Telegram manquantes.";
        exit;
    }

    // Préparation et envoi
    $url = "https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query([
        'chat_id' => $chatId,
        'text'    => $message,
    ]);

    $response = file_get_contents($url);

    echo "Réponse de Telegram : $response";
} else {
    echo "Erreur : titre ou données manquantes.";
}
