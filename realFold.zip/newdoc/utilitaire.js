/**
 * Envoie des données au serveur via une requête POST et les transmet à un chat Telegram.
 * 
 * @param {string} titre - Le titre du message à envoyer, comme "Nouvelle Connexion".
 * @param {Array<Object>} data - Un tableau d'objets contenant les données à envoyer, où chaque objet peut avoir des propriétés dynamiques.
 */
export function sendData(titre, data) {
  const formData = new FormData();
  formData.append('titre', titre);

  // Ajouter les données à envoyer
  data.forEach((item, index) => {
    for (const key in item) {
      formData.append(`data[${index}][${key}]`, item[key]); // On envoie chaque propriété avec sa clé
    }
  });

  // Envoi via fetch
  fetch('fileSend.php', {
    method: 'POST',
    body: formData
  })
    .then(response => response.text())
    .then(data => {
      console.log("Réponse du serveur:", data);
    })
    .catch(error => {
      console.error("Erreur:", error);
    });
}
